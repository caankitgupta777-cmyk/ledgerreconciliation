/**
 * app.js
 * Main Application Orchestrator for LedgerAlign PRO
 * Controls states, UI bindings, mock generator, and interactive displays.
 */

// Global Application State (Extended for Billing)
const AppState = {
  fileA: { rawRows: null, bounds: null, mapping: null, fileName: '', transactions: null },
  fileB: { rawRows: null, bounds: null, mapping: null, fileName: '', transactions: null },
  reconciliationResult: null,
  selectedUnmatchedA: [], // Holds transaction IDs selected in Ledger A
  selectedUnmatchedB: [], // Holds transaction IDs selected in Ledger B
  chartInstance: null,
  billing: {
    reconciliationsRun: 0,
    activePlan: 'free',
    reconciliationsBalance: 0,
    subscriptionExpiry: null
  }
};

// Mock Dataset Arrays
const MockLedgerA = [
  ["Ledger Account: Pioneer Distributions Ltd"],
  ["Period: 01-Apr-2024 to 30-Apr-2024"],
  [],
  ["Date", "Particulars", "Vch Type", "Vch No.", "Debit", "Credit"],
  ["01-Apr-2024", "To Sales - Goods Supplied", "Sales", "INV/001", 120500.00, ""],
  ["05-Apr-2024", "To Sales - Goods Supplied", "Sales", "INV/002", 45000.00, ""],
  ["10-Apr-2024", "By HDFC Bank Wire", "Receipt", "REC-8802", "", 120500.00],
  ["15-Apr-2024", "To Sales - Goods Supplied", "Sales", "INV/003", 89000.00, ""],
  ["20-Apr-2024", "By Cash Received", "Receipt", "REC-8840", "", 45000.00],
  ["22-Apr-2024", "To Sales - Machinery Part", "Sales", "INV/004", 72340.50, ""],
  ["25-Apr-2024", "To Sales - Special Orders", "Sales", "INV/005", 31200.00, ""],
  ["28-Apr-2024", "To Late Payment Interest Charged", "Journal", "JV-010", 500.00, ""],
  ["29-Apr-2024", "To Sales - Bulk Packing", "Sales", "INV/006", 14800.00, ""],
  ["Total", "", "", "", 373340.50, 165500.00],
  ["Closing Balance", "", "", "", 207840.50, ""]
];

const MockLedgerB = [
  ["Ledger Account: Apex Manufacturing Corp"],
  ["Period: 01-Apr-2024 to 30-Apr-2024"],
  [],
  ["Date", "Particulars", "Voucher Type", "Ref Number", "Debit", "Credit"],
  ["01-Apr-2024", "By Purchases - Materials", "Purchase", "INV/001", "", 120500.00],
  ["05-Apr-2024", "By Purchases - Materials", "Purchase", "INV/002", "", 45000.00],
  ["10-Apr-2024", "To Paid to Apex Corp", "Payment", "REC-8802", 120500.00, ""],
  ["18-Apr-2024", "By Purchases - Late Invoice Entry", "Purchase", "INV-003", "", 89000.00],
  ["20-Apr-2024", "To ICICI Bank Transfer", "Payment", "CHQ-88123", 45000.00, ""],
  ["22-Apr-2024", "By Purchases - Machine Comp", "Purchase", "INV-004", "", 72340.00],
  ["27-Apr-2024", "To Payment to Apex Account", "Payment", "TXN-902", 14800.00, ""],
  ["30-Apr-2024", "By Interest Charges Ledger", "Journal", "JV-502", "", 1200.00],
  ["Total", "", "", "", 180300.00, 327740.00],
  ["Closing Balance", "", "", "", "", 147440.00]
];

// Document Ready Initialization
document.addEventListener('DOMContentLoaded', () => {
  // Load Billing State
  initBillingState();

  // Render Lucide Icons safely
  if (typeof lucide !== 'undefined' && lucide.createIcons) {
    try {
      lucide.createIcons();
    } catch (e) {
      console.warn('Failed to render Lucide icons:', e);
    }
  }
  
  // Set up Event Listeners
  initEventListeners();
});

/**
 * Configure DOM Event Listeners
 */
/**
 * Safe Event Listener Helper
 * Prevents script crashes if elements are not present in the DOM
 */
function safeAddListener(id, event, callback) {
  const el = document.getElementById(id);
  if (el) {
    el.addEventListener(event, callback);
  } else {
    console.warn(`Element with ID "${id}" not found in DOM.`);
  }
}

function initEventListeners() {
  // Config range slider label binder
  const slider = document.getElementById('cfg-date-tolerance');
  const sliderVal = document.getElementById('cfg-date-val');
  if (slider && sliderVal) {
    slider.addEventListener('input', () => {
      sliderVal.textContent = slider.value === '0' ? 'Exact Date' : `${slider.value} Days`;
    });
  }

  // Drag and Drop Binds
  setupDropZone('drop-zone-a', 'file-a', 'A');
  setupDropZone('drop-zone-b', 'file-b', 'B');

  // Manual mapping selections change events
  setupMappingSelectorListeners('a');
  setupMappingSelectorListeners('b');

  // Trigger Action Buttons
  safeAddListener('btn-run-reconciliation', 'click', runReconciliation);
  safeAddListener('btn-generate-mock', 'click', loadSampleData);
  safeAddListener('btn-back-to-import', 'click', showImportView);
  safeAddListener('btn-export-excel', 'click', exportReconciliationReport);

  // Tab bindings
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const tabId = e.currentTarget.getAttribute('data-tab');
      switchTab(tabId);
    });
  });

  // Reconciled Quality Filter pills
  document.querySelectorAll('#match-type-pills .pill').forEach(pill => {
    pill.addEventListener('click', (e) => {
      document.querySelectorAll('#match-type-pills .pill').forEach(p => p.classList.remove('active'));
      e.currentTarget.classList.add('active');
      renderReconciledPairs(e.currentTarget.getAttribute('data-filter'));
    });
  });

  // Search input filters
  safeAddListener('txt-search-unmatched', 'input', filterUnmatchedTables);
  safeAddListener('txt-search-reconciled', 'input', () => {
    const activeFilter = document.querySelector('#match-type-pills .pill.active')?.getAttribute('data-filter') || 'ALL';
    renderReconciledPairs(activeFilter);
  });

  // Unmatched Header Multi-select Checkboxes
  safeAddListener('chk-all-unmatched-a', 'change', (e) => {
    toggleSelectAll('tbody-unmatched-a', e.target.checked, 'A');
  });
  safeAddListener('chk-all-unmatched-b', 'change', (e) => {
    toggleSelectAll('tbody-unmatched-b', e.target.checked, 'B');
  });

  // Manual reconciliation actions
  safeAddListener('btn-reset-selection', 'click', clearManualSelection);
  safeAddListener('btn-manual-reconcile', 'click', executeManualReconciliation);

  // Billing and Premium paywall listeners
  safeAddListener('btn-billing-trigger', 'click', () => openBillingModal(AppState.billing?.activePlan === 'free' ? 'monthly' : AppState.billing?.activePlan));
  safeAddListener('btn-trial-upgrade', 'click', () => openBillingModal('monthly'));
  safeAddListener('btn-close-billing-modal', 'click', () => {
    const modal = document.getElementById('billing-modal');
    if (modal) modal.classList.remove('active');
  });

  // Billing Card selections click bounds
  document.querySelectorAll('#pricing-plans-grid .plan-card').forEach(card => {
    card.addEventListener('click', (e) => {
      if (e.target.tagName !== 'BUTTON' && !e.target.closest('.quantity-selector')) {
        const planId = card.getAttribute('data-plan');
        selectPlanCard(planId, true);
      }
    });
    const selectBtn = card.querySelector('button.w-full');
    if (selectBtn) {
      selectBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const planId = card.getAttribute('data-plan');
        selectPlanCard(planId, true);
      });
    }
  });

  // Quantity + / - button triggers
  safeAddListener('btn-paygo-minus', 'click', (e) => {
    e.stopPropagation();
    if (selectedQty > 1) {
      selectedQty--;
      const qtySpan = document.getElementById('lbl-paygo-qty');
      if (qtySpan) qtySpan.textContent = selectedQty;
      updateOrderSummary('paygo');
    }
  });
  safeAddListener('btn-paygo-plus', 'click', (e) => {
    e.stopPropagation();
    selectedQty++;
    const qtySpan = document.getElementById('lbl-paygo-qty');
    if (qtySpan) qtySpan.textContent = selectedQty;
    updateOrderSummary('paygo');
  });

  // Payment Tabs switching
  safeAddListener('tab-pay-card', 'click', () => {
    const tabCard = document.getElementById('tab-pay-card');
    const tabUpi = document.getElementById('tab-pay-upi');
    const panelCard = document.getElementById('panel-card-form');
    const panelUpi = document.getElementById('panel-upi-scan');
    if (tabCard) tabCard.classList.add('active');
    if (tabUpi) tabUpi.classList.remove('active');
    if (panelCard) panelCard.classList.add('active');
    if (panelUpi) panelUpi.classList.remove('active');
  });
  
  safeAddListener('tab-pay-upi', 'click', () => {
    const tabCard = document.getElementById('tab-pay-card');
    const tabUpi = document.getElementById('tab-pay-upi');
    const panelCard = document.getElementById('panel-card-form');
    const panelUpi = document.getElementById('panel-upi-scan');
    if (tabUpi) tabUpi.classList.add('active');
    if (tabCard) tabCard.classList.remove('active');
    if (panelUpi) panelUpi.classList.add('active');
    if (panelCard) panelCard.classList.remove('active');
  });

  // Card Number auto-spacing formatting (1234 5678 ...)
  const cardInput = document.getElementById('txt-card-number');
  if (cardInput) {
    cardInput.addEventListener('input', (e) => {
      let val = e.target.value.replace(/\D/g, '');
      let formatted = '';
      for (let i = 0; i < val.length; i++) {
        if (i > 0 && i % 4 === 0) formatted += ' ';
        formatted += val[i];
      }
      e.target.value = formatted.substring(0, 19);
    });
  }

  // Expiry Date slash auto-fill formatting (MM/YY)
  const expInput = document.getElementById('txt-card-expiry');
  if (expInput) {
    expInput.addEventListener('input', (e) => {
      let val = e.target.value.replace(/\D/g, '');
      if (val.length >= 2) {
        e.target.value = val.substring(0, 2) + '/' + val.substring(2, 4);
      } else {
        e.target.value = val;
      }
    });
  }

  // Pay button submit action trigger
  safeAddListener('btn-submit-payment', 'click', submitBillingPayment);

  // Success view close / activation button
  safeAddListener('btn-activate-premium', 'click', () => {
    const modal = document.getElementById('billing-modal');
    if (modal) modal.classList.remove('active');
    if (AppState.fileA.rawRows !== null && AppState.fileB.rawRows !== null) {
      runReconciliation();
    } else {
      showToast("Premium plan activated! Upload your ledger books to start matching.", "success");
    }
  });

  // Reset State Developer Tool anchor trigger
  safeAddListener('btn-reset-billing-state', 'click', resetBillingState);
}

/**
 * Show Toast Notification
 */
function showToast(message, type = 'info') {
  const toast = document.getElementById('toast-notification');
  const toastMsg = toast.querySelector('.toast-message');
  
  toastMsg.textContent = message;
  toast.className = `toast active`;
  
  setTimeout(() => {
    toast.classList.remove('active');
  }, 4000);
}

/**
 * Navigate to Import setup View
 */
function showImportView() {
  document.getElementById('view-dashboard').classList.remove('active');
  document.getElementById('view-import').classList.add('active');
}

/**
 * Navigate to Dashboard view
 */
function showDashboardView() {
  document.getElementById('view-import').classList.remove('active');
  document.getElementById('view-dashboard').classList.add('active');
}

/**
 * Tab Navigation Manager
 */
function switchTab(tabId) {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    if (btn.getAttribute('data-tab') === tabId) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });

  document.querySelectorAll('.tab-panel').forEach(panel => {
    if (panel.id === tabId) {
      panel.classList.add('active');
    } else {
      panel.classList.remove('active');
    }
  });
}

/**
 * Drag and drop area configuration
 */
function setupDropZone(zoneId, inputId, ledgerKey) {
  const dropZone = document.getElementById(zoneId);
  const fileInput = document.getElementById(inputId);

  // Drag over states
  dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('dragover');
  });

  dropZone.addEventListener('dragleave', () => {
    dropZone.classList.remove('dragover');
  });

  dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('dragover');
    if (e.dataTransfer.files.length > 0) {
      handleSpreadsheetFile(e.dataTransfer.files[0], ledgerKey);
    }
  });

  fileInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
      handleSpreadsheetFile(e.target.files[0], ledgerKey);
    }
  });

  // Clear button click listener
  const clearBtn = document.getElementById(`btn-clear-${ledgerKey.toLowerCase()}`);
  clearBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    resetLedgerState(ledgerKey);
  });
}

/**
 * Reset ledger configuration back to empty
 */
function resetLedgerState(ledgerKey) {
  const key = ledgerKey.toLowerCase();
  AppState[`file${ledgerKey}`] = { rawRows: null, bounds: null, mapping: null, fileName: '', transactions: null };
  
  // Clear input
  document.getElementById(`file-${key}`).value = '';
  
  // Hide info panel & mapping preview
  document.getElementById(`file-info-${key}`).classList.remove('active');
  document.getElementById(`mapper-${key}`).classList.remove('active');
  
  // Show drag zone
  document.getElementById(`drop-zone-${key}`).style.display = 'block';
  
  validateRunButton();
}

/**
 * Load Sample Mock ledgers instantly into workflow
 */
function loadSampleData() {
  // Inject mock data A
  processRawMatrix(MockLedgerA, 'Apex_A_Books_Pioneer.xlsx', 'A');
  // Inject mock data B
  processRawMatrix(MockLedgerB, 'Pioneer_B_Books_Apex.xlsx', 'B');

  showToast("Mock ledger files imported! Confirm column mapping and click Execute.", "success");
}

/**
 * Read and ingest selected local spreadsheet
 */
async function handleSpreadsheetFile(file, ledgerKey) {
  try {
    const rawRows = await Parser.parseRawFile(file);
    processRawMatrix(rawRows, file.name, ledgerKey);
    showToast(`Successfully parsed ${file.name}`, 'success');
  } catch (error) {
    showToast(error.message, 'error');
  }
}

/**
 * Core parsing coordinator: isolates transaction rows and generates column options selectors
 */
function processRawMatrix(rawRows, fileName, ledgerKey) {
  const key = ledgerKey.toLowerCase();
  const state = AppState[`file${ledgerKey}`];
  
  state.rawRows = rawRows;
  state.fileName = fileName;
  state.bounds = Parser.detectTableBounds(rawRows);
  state.mapping = Parser.proposeColumnMapping(state.bounds.cleanHeaders);

  // Update UI file badge details
  document.getElementById(`drop-zone-${key}`).style.display = 'none';
  document.getElementById(`file-name-${key}`).textContent = fileName;
  
  // Calculate sizing
  const byteLen = JSON.stringify(rawRows).length; // Rough sizing estimation
  const sizeKb = (byteLen / 1024).toFixed(1);
  document.getElementById(`file-size-${key}`).textContent = `${sizeKb} KB`;
  document.getElementById(`file-info-${key}`).classList.add('active');

  // Crop Range display
  document.getElementById(`crop-range-${key}`).textContent = `Rows ${state.bounds.headerRowIndex + 2} to ${state.bounds.endRowIndex}`;

  // Populate dropdown options selectors
  populateMapperDropdowns(key, state.bounds.cleanHeaders, state.mapping);

  // Display mapper panel
  document.getElementById(`mapper-${key}`).classList.add('active');

  // Instantly map and compile transactions
  compileTransactions(ledgerKey);

  validateRunButton();
}

/**
 * Injects clean options into mapping elements
 */
function populateMapperDropdowns(key, headers, mapping) {
  const fields = ['date', 'particulars', 'vchno', 'vchtype', 'debit', 'credit'];
  
  fields.forEach(field => {
    const select = document.getElementById(`map-${key}-${field}`);
    select.innerHTML = '<option value="-1">-- Unmapped / None --</option>';
    
    headers.forEach((h, idx) => {
      const option = document.createElement('option');
      option.value = idx;
      option.textContent = `Col ${idx + 1}: ${h || '(Blank Header)'}`;
      
      // Auto selection matching logic
      const mappedIdx = mapping[field === 'vchno' ? 'vchNo' : field === 'vchtype' ? 'vchType' : field];
      if (mappedIdx === idx) {
        option.selected = true;
      }
      select.appendChild(option);
    });
  });
}

/**
 * Event handler for when user manually changes column maps in UI
 */
function setupMappingSelectorListeners(key) {
  const fields = ['date', 'particulars', 'vchno', 'vchtype', 'debit', 'credit'];
  fields.forEach(field => {
    document.getElementById(`map-${key}-${field}`).addEventListener('change', () => {
      updateMappingFromUI(key);
      compileTransactions(key.toUpperCase());
    });
  });
}

/**
 * Updates mapping state values from select options
 */
function updateMappingFromUI(key) {
  const state = AppState[`file${key.toUpperCase()}`];
  if (!state.mapping) return;

  state.mapping.date = parseInt(document.getElementById(`map-${key}-date`).value);
  state.mapping.particulars = parseInt(document.getElementById(`map-${key}-particulars`).value);
  state.mapping.vchNo = parseInt(document.getElementById(`map-${key}-vchno`).value);
  state.mapping.vchType = parseInt(document.getElementById(`map-${key}-vchtype`).value);
  state.mapping.debit = parseInt(document.getElementById(`map-${key}-debit`).value);
  state.mapping.credit = parseInt(document.getElementById(`map-${key}-credit`).value);
}

/**
 * Run compiler normalizer on raw rows
 */
function compileTransactions(ledgerKey) {
  const state = AppState[`file${ledgerKey}`];
  if (!state.rawRows) return;

  state.transactions = Parser.standardizeTransactions(state.rawRows, state.bounds, state.mapping);
}

/**
 * Determines if execution can proceed (both ledgers uploaded)
 */
function validateRunButton() {
  const runBtn = document.getElementById('btn-run-reconciliation');
  const hasA = AppState.fileA.rawRows !== null;
  const hasB = AppState.fileB.rawRows !== null;
  
  runBtn.disabled = !(hasA && hasB);
}

/**
 * Triggers Match Engine and compiles dashboard elements
 */
function runReconciliation() {
  if (!AppState.fileA.transactions || !AppState.fileB.transactions) {
    showToast("Transaction models missing. Re-upload datasets.", "error");
    return;
  }

  // ----------------------------------------------------
  // Premium Billing Security Protection Gate interceptor
  // ----------------------------------------------------
  const bill = AppState.billing;
  let allowedToProceed = false;

  if (bill.activePlan === 'monthly' || bill.activePlan === 'yearly') {
    if (bill.subscriptionExpiry && Date.now() > bill.subscriptionExpiry) {
      bill.activePlan = 'free';
      bill.subscriptionExpiry = null;
      saveBillingState();
      showToast("Your subscription active window has expired. Please choose a new pricing plan.", "error");
      openBillingModal('monthly');
      return;
    }
    allowedToProceed = true;
  } else if (bill.activePlan === 'paygo') {
    if (bill.reconciliationsBalance > 0) {
      bill.reconciliationsBalance--;
      saveBillingState();
      showToast(`1 Paid reconciliation run debited. Balance: ${bill.reconciliationsBalance} remaining.`, "success");
      allowedToProceed = true;
    } else {
      showToast("Your pay-as-you-go balance is ₹0. Please recharge to continue.", "error");
      openBillingModal('paygo');
      return;
    }
  } else {
    // Free Trial
    if (bill.reconciliationsRun < 2) {
      bill.reconciliationsRun++;
      saveBillingState();
      showToast(`Free Trial Run: ${bill.reconciliationsRun} of 2 processed.`, "info");
      allowedToProceed = true;
    } else {
      showToast("Free trial limit exceeded! Please purchase a premium plan to execute reconciliation.", "error");
      openBillingModal('monthly');
      return;
    }
  }

  if (!allowedToProceed) return;

  // Fetch configs
  const dateTolerance = document.getElementById('cfg-date-tolerance').value;
  const roundingTolerance = parseFloat(document.getElementById('cfg-rounding-tolerance').value) || 0;
  const useVoucherTypes = document.getElementById('cfg-voucher-types').checked;

  // Run engine
  AppState.reconciliationResult = Matcher.reconcile(
    AppState.fileA.transactions,
    AppState.fileB.transactions,
    { dateTolerance, roundingTolerance, useVoucherTypes }
  );

  // Reset manual selections
  AppState.selectedUnmatchedA = [];
  AppState.selectedUnmatchedB = [];
  document.getElementById('manual-match-drawer').classList.remove('active');

  // Trigger visual updates
  updateDashboardKPIs();
  renderOverviewVisuals();
  renderUnmatchedWorkspace();
  renderReconciledPairs('ALL');

  // Nav
  showDashboardView();
  switchTab('tab-overview');
  showToast("Reconciliation process complete!", "success");
}

/**
 * Updates KPI values across cards
 */
function updateDashboardKPIs() {
  const res = AppState.reconciliationResult;
  if (!res) return;

  // Set visual texts
  document.getElementById('lbl-reconciliation-percent').textContent = `${res.stats.reconciliationPercentage}%`;
  document.getElementById('lbl-reconciled-count').textContent = res.stats.recompiledCount || (res.stats.reconciledA + res.stats.reconciledB);
  document.getElementById('lbl-total-count').textContent = res.stats.totalA + res.stats.totalB;

  // KPI Ring Offset: circumference is 213.62
  const circle = document.getElementById('progress-percent-ring');
  const offset = 213.62 - (res.stats.reconciliationPercentage / 100) * 213.62;
  circle.style.strokeDashoffset = offset;

  // Net Balance A
  const netA = res.stats.netA;
  const valA = document.getElementById('lbl-net-balance-a');
  valA.textContent = `₹${Math.abs(netA).toLocaleString('en-IN', { minimumFractionDigits: 2 })} ${netA >= 0 ? 'Dr' : 'Cr'}`;
  valA.className = `kpi-value ${netA >= 0 ? 'text-dr' : 'text-cr'}`;
  document.getElementById('lbl-dr-total-a').textContent = `₹${res.stats.totalDebitA.toLocaleString('en-IN')}`;
  document.getElementById('lbl-cr-total-a').textContent = `₹${res.stats.totalCreditA.toLocaleString('en-IN')}`;

  // Net Balance B
  const netB = res.stats.netB;
  const valB = document.getElementById('lbl-net-balance-b');
  valB.textContent = `₹${Math.abs(netB).toLocaleString('en-IN', { minimumFractionDigits: 2 })} ${netB >= 0 ? 'Dr' : 'Cr'}`;
  valB.className = `kpi-value ${netB >= 0 ? 'text-dr' : 'text-cr'}`;
  document.getElementById('lbl-dr-total-b').textContent = `₹${res.stats.totalDebitB.toLocaleString('en-IN')}`;
  document.getElementById('lbl-cr-total-b').textContent = `₹${res.stats.totalCreditB.toLocaleString('en-IN')}`;

  // Variance
  const variance = res.stats.variance;
  const card = document.getElementById('card-variance');
  const valVar = document.getElementById('lbl-variance-amount');
  const statVar = document.getElementById('lbl-variance-status');

  valVar.textContent = `₹${Math.abs(variance).toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
  
  if (Math.abs(variance) <= 0.01) {
    card.className = "kpi-card glass-panel in-balance";
    statVar.textContent = "Perfectly Balanced Ledger";
    valVar.className = "kpi-value text-cr";
  } else {
    card.className = "kpi-card glass-panel out-of-balance";
    statVar.textContent = `Net Out of Balance variance`;
    valVar.className = "kpi-value text-dr";
  }

  // Update tabs numbers indicators
  document.getElementById('badge-unmatched-count').textContent = res.unmatchedA.length + res.unmatchedB.length;
  document.getElementById('badge-matched-count').textContent = res.matchedPairs.length;

  // Active toolbar configs summary
  const dateTolerance = document.getElementById('cfg-date-tolerance').value;
  const roundingTolerance = parseFloat(document.getElementById('cfg-rounding-tolerance').value) || 0;
  document.getElementById('lbl-active-tolerance').textContent = `Date tolerance: ${dateTolerance === '0' ? 'Exact' : dateTolerance + ' Days'}`;
  document.getElementById('lbl-active-rounding').textContent = `Rounding: ±₹${roundingTolerance.toFixed(2)}`;
}

/**
 * Compiles Overview tab, renders doughnut chart, lists match types
 */
function renderOverviewVisuals() {
  const res = AppState.reconciliationResult;
  if (!res) return;

  // Ledger metadata file names
  document.getElementById('lbl-meta-a-name').textContent = AppState.fileA.fileName;
  document.getElementById('lbl-meta-b-name').textContent = AppState.fileB.fileName;

  document.getElementById('lbl-meta-a-unmatched').textContent = res.unmatchedA.length;
  document.getElementById('lbl-meta-b-unmatched').textContent = res.unmatchedB.length;

  // Extract unique voucher types found in ledgers
  const getVchSummaryString = (txs) => {
    const counts = {};
    txs.forEach(t => { counts[t.vchType] = (counts[t.vchType] || 0) + 1; });
    return Object.keys(counts).map(k => `${k} (${counts[k]})`).join(', ');
  };
  document.getElementById('lbl-meta-a-types').textContent = getVchSummaryString(AppState.fileA.transactions);
  document.getElementById('lbl-meta-b-types').textContent = getVchSummaryString(AppState.fileB.transactions);

  // Group Matches by type
  const matchTypes = {
    EXACT: { title: 'Exact Matches', desc: 'Identical amount, date, and reference.', count: 0, color: 'bg-exact' },
    TIMING: { title: 'Timing Differences', desc: 'Matched reference and amount with offset dates.', count: 0, color: 'bg-timing' },
    ROUNDING: { title: 'Rounding Adjustments', desc: 'Amount variance resolved within threshold.', count: 0, color: 'bg-rounding' },
    FUZZY: { title: 'Fuzzy Ref/Particulars', desc: 'Resolved via spelling proximity check.', count: 0, color: 'bg-fuzzy' },
    AMOUNT_ONLY: { title: 'Amount & Date Alignments', desc: 'Identical amount/close dates with differing references.', count: 0, color: 'bg-amount-only' },
    MANUAL: { title: 'Manual Overrides', desc: 'Manually paired by user overrides.', count: 0, color: 'bg-manual' }
  };

  res.matchedPairs.forEach(p => {
    if (matchTypes[p.matchType]) {
      matchTypes[p.matchType].count++;
    }
  });

  const breakdownContainer = document.getElementById('match-type-breakdown');
  breakdownContainer.innerHTML = '';

  const totalPairs = res.matchedPairs.length || 1;

  Object.keys(matchTypes).forEach(type => {
    const info = matchTypes[type];
    const percentage = Math.round((info.count / totalPairs) * 100);

    const div = document.createElement('div');
    div.className = 'breakdown-item';
    div.innerHTML = `
      <div class="breakdown-item-left">
        <div class="breakdown-color-bar ${info.color}"></div>
        <div class="breakdown-info">
          <h5>${info.title}</h5>
          <p>${info.desc}</p>
        </div>
      </div>
      <div class="breakdown-stats">
        <div class="breakdown-count">${info.count} pairs</div>
        <div class="breakdown-percent">${percentage}% of matches</div>
      </div>
    `;
    breakdownContainer.appendChild(div);
  });

  // Render Doughnut Chart using Chart.js
  const totalReconciled = res.stats.reconciledA + res.stats.reconciledB;
  const totalUnmatched = res.unmatchedA.length + res.unmatchedB.length;

  if (AppState.chartInstance) {
    AppState.chartInstance.destroy();
  }

  const ctx = document.getElementById('chart-reconciliation').getContext('2d');
  AppState.chartInstance = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Reconciled (Matched)', 'Unmatched (Ledger A)', 'Unmatched (Ledger B)'],
      datasets: [{
        data: [res.matchedPairs.length * 2, res.unmatchedA.length, res.unmatchedB.length],
        backgroundColor: ['#10b981', '#3b82f6', '#ec4899'],
        borderWidth: 1,
        borderColor: '#1f2937'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: { color: '#f3f4f6', font: { family: 'Inter', size: 11 } }
        }
      },
      cutout: '65%'
    }
  });
}

/**
 * Builds side-by-side split grids for Unmatched transactions
 */
function renderUnmatchedWorkspace() {
  const res = AppState.reconciliationResult;
  if (!res) return;

  // Clear selections arrays
  AppState.selectedUnmatchedA = [];
  AppState.selectedUnmatchedB = [];

  // Reset master checkboxes
  document.getElementById('chk-all-unmatched-a').checked = false;
  document.getElementById('chk-all-unmatched-b').checked = false;

  // Summary header counts
  document.getElementById('lbl-unmatched-count-a').textContent = `${res.unmatchedA.length} items`;
  document.getElementById('lbl-unmatched-count-b').textContent = `${res.unmatchedB.length} items`;

  // Dynamic filter search term
  const query = document.getElementById('txt-search-unmatched').value.toLowerCase().trim();

  // Populate Unmatched Ledger A
  const tbodyA = document.getElementById('tbody-unmatched-a');
  tbodyA.innerHTML = '';
  
  let totalSumA = 0;
  
  res.unmatchedA.forEach(tx => {
    // Apply search filter
    if (query && !tx.particulars.toLowerCase().includes(query) && !tx.vchNo.toLowerCase().includes(query) && !tx.amount.toString().includes(query)) {
      return;
    }
    
    totalSumA += tx.amount;
    const tr = document.createElement('tr');
    tr.id = `row-unmatched-a-${tx.id}`;
    tr.innerHTML = `
      <td><input type="checkbox" class="chk-row-a" value="${tx.id}"></td>
      <td>${formatDisplayDate(tx.date)}</td>
      <td><strong>${tx.vchNo || '(No Ref)'}</strong></td>
      <td><span class="vch-badge">${tx.vchType}</span></td>
      <td>${tx.particulars}</td>
      <td class="text-right text-dr">${tx.debit > 0 ? '₹' + tx.debit.toLocaleString('en-IN', { minimumFractionDigits: 2 }) : '-'}</td>
      <td class="text-right text-cr">${tx.credit > 0 ? '₹' + tx.credit.toLocaleString('en-IN', { minimumFractionDigits: 2 }) : '-'}</td>
    `;
    
    // Checkbox selector bind
    tr.querySelector('input').addEventListener('change', (e) => {
      handleRowSelection(tx.id, 'A', e.target.checked);
    });
    // Click on row selects it
    tr.addEventListener('click', (e) => {
      if (e.target.tagName !== 'INPUT') {
        const chk = tr.querySelector('input');
        chk.checked = !chk.checked;
        handleRowSelection(tx.id, 'A', chk.checked);
      }
    });

    tbodyA.appendChild(tr);
  });
  document.getElementById('lbl-unmatched-sum-a').textContent = `₹${totalSumA.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;

  // Populate Unmatched Ledger B
  const tbodyB = document.getElementById('tbody-unmatched-b');
  tbodyB.innerHTML = '';
  
  let totalSumB = 0;

  res.unmatchedB.forEach(tx => {
    if (query && !tx.particulars.toLowerCase().includes(query) && !tx.vchNo.toLowerCase().includes(query) && !tx.amount.toString().includes(query)) {
      return;
    }
    
    totalSumB += tx.amount;
    const tr = document.createElement('tr');
    tr.id = `row-unmatched-b-${tx.id}`;
    tr.innerHTML = `
      <td><input type="checkbox" class="chk-row-b" value="${tx.id}"></td>
      <td>${formatDisplayDate(tx.date)}</td>
      <td><strong>${tx.vchNo || '(No Ref)'}</strong></td>
      <td><span class="vch-badge">${tx.vchType}</span></td>
      <td>${tx.particulars}</td>
      <td class="text-right text-dr">${tx.debit > 0 ? '₹' + tx.debit.toLocaleString('en-IN', { minimumFractionDigits: 2 }) : '-'}</td>
      <td class="text-right text-cr">${tx.credit > 0 ? '₹' + tx.credit.toLocaleString('en-IN', { minimumFractionDigits: 2 }) : '-'}</td>
    `;

    tr.querySelector('input').addEventListener('change', (e) => {
      handleRowSelection(tx.id, 'B', e.target.checked);
    });
    tr.addEventListener('click', (e) => {
      if (e.target.tagName !== 'INPUT') {
        const chk = tr.querySelector('input');
        chk.checked = !chk.checked;
        handleRowSelection(tx.id, 'B', chk.checked);
      }
    });

    tbodyB.appendChild(tr);
  });
  document.getElementById('lbl-unmatched-sum-b').textContent = `₹${totalSumB.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;

  // Update central panel sums
  updateManualMatchingUI();
}

/**
 * Filter unmatched tables interactively
 */
function filterUnmatchedTables() {
  renderUnmatchedWorkspace();
}

/**
 * Handle checkbox row selection in splits
 */
function handleRowSelection(id, ledgerKey, isSelected) {
  const arr = ledgerKey === 'A' ? AppState.selectedUnmatchedA : AppState.selectedUnmatchedB;
  const rowId = `row-unmatched-${ledgerKey.toLowerCase()}-${id}`;
  const tr = document.getElementById(rowId);

  if (isSelected) {
    if (!arr.includes(id)) arr.push(id);
    tr?.classList.add('row-selected');
  } else {
    const idx = arr.indexOf(id);
    if (idx !== -1) arr.splice(idx, 1);
    tr?.classList.remove('row-selected');
  }

  // Master checkboxes status check
  const allChks = document.querySelectorAll(`.chk-row-${ledgerKey.toLowerCase()}`);
  const master = document.getElementById(`chk-all-unmatched-${ledgerKey.toLowerCase()}`);
  if (allChks.length > 0) {
    master.checked = Array.from(allChks).every(c => c.checked);
  }

  updateManualMatchingUI();
}

/**
 * Handles master check selection triggers
 */
function toggleSelectAll(tbodyId, isChecked, ledgerKey) {
  const tbody = document.getElementById(tbodyId);
  tbody.querySelectorAll(`input[type="checkbox"]`).forEach(chk => {
    chk.checked = isChecked;
    handleRowSelection(chk.value, ledgerKey, isChecked);
  });
}

/**
 * Sum and update visual elements of floating manual match box
 */
function updateManualMatchingUI() {
  const res = AppState.reconciliationResult;
  if (!res) return;

  const countA = AppState.selectedUnmatchedA.length;
  const countB = AppState.selectedUnmatchedB.length;

  document.getElementById('lbl-sel-count-a').textContent = countA;
  document.getElementById('lbl-sel-count-b').textContent = countB;

  // Calculate sum A
  let sumA = 0;
  AppState.selectedUnmatchedA.forEach(id => {
    const item = res.unmatchedA.find(x => x.id === id);
    if (item) sumA += item.amount;
  });
  document.getElementById('lbl-sel-sum-a').textContent = `₹${sumA.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;

  // Calculate sum B
  let sumB = 0;
  AppState.selectedUnmatchedB.forEach(id => {
    const item = res.unmatchedB.find(x => x.id === id);
    if (item) sumB += item.amount;
  });
  document.getElementById('lbl-sel-sum-b').textContent = `₹${sumB.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;

  // Variance
  const variance = Math.abs(sumA - sumB);
  document.getElementById('lbl-sel-variance').textContent = `₹${variance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;

  // Show/Hide Drawer
  const drawer = document.getElementById('manual-match-drawer');
  if (countA > 0 || countB > 0) {
    drawer.classList.add('active');
  } else {
    drawer.classList.remove('active');
  }
}

/**
 * Clear current selections
 */
function clearManualSelection() {
  document.getElementById('tbody-unmatched-a').querySelectorAll('input[type="checkbox"]').forEach(c => c.checked = false);
  document.getElementById('tbody-unmatched-b').querySelectorAll('input[type="checkbox"]').forEach(c => c.checked = false);

  AppState.selectedUnmatchedA = [];
  AppState.selectedUnmatchedB = [];
  
  document.getElementById('chk-all-unmatched-a').checked = false;
  document.getElementById('chk-all-unmatched-b').checked = false;

  // Clear rows selected status
  document.querySelectorAll('.data-table tr').forEach(r => r.classList.remove('row-selected'));

  updateManualMatchingUI();
}

/**
 * Executes a manual match override based on user row selections
 */
function executeManualReconciliation() {
  const res = AppState.reconciliationResult;
  if (!res) return;

  const countA = AppState.selectedUnmatchedA.length;
  const countB = AppState.selectedUnmatchedB.length;

  if (countA === 0 && countB === 0) return;

  // Confirm match override confirmation
  const notesInput = document.getElementById('txt-manual-notes');
  const notes = notesInput.value.trim() || 'Manually reconciled override';

  // Gather matched items arrays
  const itemsA = AppState.selectedUnmatchedA.map(id => res.unmatchedA.find(x => x.id === id)).filter(Boolean);
  const itemsB = AppState.selectedUnmatchedB.map(id => res.unmatchedB.find(x => x.id === id)).filter(Boolean);

  // Group into composite items or separate match pairings
  // To handle many-to-many or single-sided manual journals cleanly,
  // we will construct a single unified manual match pair with composite structures.
  const matchId = `match_manual_${Date.now()}`;
  
  // Construct aggregated composite entities for matching representation
  const compositeA = itemsA.length === 1 ? itemsA[0] : {
    id: `comp_a_${Date.now()}`,
    date: itemsA[0]?.date || '',
    particulars: `[Composite] ${itemsA.map(x => x.particulars).join(' + ')}`,
    vchNo: itemsA.map(x => x.vchNo).filter(Boolean).join(', ') || 'Manual Group',
    vchType: 'JOURNAL',
    debit: itemsA.reduce((s, x) => s + (x.debit || 0), 0),
    credit: itemsA.reduce((s, x) => s + (x.credit || 0), 0),
    amount: itemsA.reduce((s, x) => s + x.amount, 0),
    type: itemsA[0]?.type || 'DR'
  };

  const compositeB = itemsB.length === 1 ? itemsB[0] : {
    id: `comp_b_${Date.now()}`,
    date: itemsB[0]?.date || '',
    particulars: `[Composite] ${itemsB.map(x => x.particulars).join(' + ')}`,
    vchNo: itemsB.map(x => x.vchNo).filter(Boolean).join(', ') || 'Manual Group',
    vchType: 'JOURNAL',
    debit: itemsB.reduce((s, x) => s + (x.debit || 0), 0),
    credit: itemsB.reduce((s, x) => s + (x.credit || 0), 0),
    amount: itemsB.reduce((s, x) => s + x.amount, 0),
    type: itemsB[0]?.type || 'CR'
  };

  // Add items details flag to match
  const matchRecord = {
    id: matchId,
    itemA: { ...compositeA, matched: true, matchId },
    itemB: { ...compositeB, matched: true, matchId },
    matchType: 'MANUAL',
    amountDiff: compositeA.amount - compositeB.amount,
    dateDiff: (compositeA.date && compositeB.date) ? Matcher.getDateDiffDays(compositeA.date, compositeB.date) : 0,
    notes,
    originalItemsA: itemsA, // Keep traces to enable clean undo action!
    originalItemsB: itemsB
  };

  // 1. Add to reconciled lists
  res.matchedPairs.push(matchRecord);

  // 2. Remove originals from unmatched arrays
  res.unmatchedA = res.unmatchedA.filter(x => !AppState.selectedUnmatchedA.includes(x.id));
  res.unmatchedB = res.unmatchedB.filter(x => !AppState.selectedUnmatchedB.includes(x.id));

  // 3. Update stats reconciled volumes
  res.stats.reconciledA += itemsA.length;
  res.stats.reconciledB += itemsB.length;

  // Clean selections
  clearManualSelection();
  notesInput.value = '';

  // Redraw
  updateDashboardKPIs();
  renderOverviewVisuals();
  renderUnmatchedWorkspace();
  renderReconciledPairs('ALL');

  showToast("Transactions reconciled manually!", "success");
}

/**
 * Undoes a matched pairing, putting items back to unmatched split lists
 */
function undoReconciliation(matchId) {
  const res = AppState.reconciliationResult;
  if (!res) return;

  const idx = res.matchedPairs.findIndex(x => x.id === matchId);
  if (idx === -1) return;

  const match = res.matchedPairs[idx];

  // If manual composite match, restore all underlying components
  if (match.matchType === 'MANUAL' && (match.originalItemsA || match.originalItemsB)) {
    if (match.originalItemsA) {
      match.originalItemsA.forEach(x => res.unmatchedA.push({ ...x, matched: false, matchId: null }));
      res.stats.reconciledA -= match.originalItemsA.length;
    }
    if (match.originalItemsB) {
      match.originalItemsB.forEach(x => res.unmatchedB.push({ ...x, matched: false, matchId: null }));
      res.stats.reconciledB -= match.originalItemsB.length;
    }
  } else {
    // Standard match
    res.unmatchedA.push({ ...match.itemA, matched: false, matchId: null });
    res.unmatchedB.push({ ...match.itemB, matched: false, matchId: null });
    
    res.stats.reconciledA--;
    res.stats.reconciledB--;
  }

  // Remove from matches array
  res.matchedPairs.splice(idx, 1);

  // Sort unmatched lists by date again
  res.unmatchedA.sort((x, y) => new Date(x.date) - new Date(y.date));
  res.unmatchedB.sort((x, y) => new Date(x.date) - new Date(y.date));

  // Redraw
  updateDashboardKPIs();
  renderOverviewVisuals();
  renderUnmatchedWorkspace();
  
  const activeFilter = document.querySelector('#match-type-pills .pill.active').getAttribute('data-filter');
  renderReconciledPairs(activeFilter);

  showToast("Match undone. Items restored to unmatched grids.", "info");
}

/**
 * Render Reconciled Pairs Table with filtering
 */
function renderReconciledPairs(filterType = 'ALL') {
  const res = AppState.reconciliationResult;
  if (!res) return;

  const tbody = document.getElementById('tbody-reconciled-pairs');
  tbody.innerHTML = '';

  const searchQuery = document.getElementById('txt-search-reconciled').value.toLowerCase().trim();

  // Filter matched records
  const filtered = res.matchedPairs.filter(p => {
    // Type Filter
    if (filterType !== 'ALL' && p.matchType !== filterType) {
      return false;
    }
    
    // Search Query Filter
    if (searchQuery) {
      const matchText = (
        p.itemA.particulars + " " + p.itemA.vchNo + " " + p.itemA.amount + " " +
        p.itemB.particulars + " " + p.itemB.vchNo + " " + p.itemB.amount + " " + (p.notes || "")
      ).toLowerCase();
      return matchText.includes(searchQuery);
    }

    return true;
  });

  document.getElementById('badge-matched-count').textContent = res.matchedPairs.length;

  if (filtered.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="4" class="text-center" style="padding: 3rem; color: var(--text-dimmed);">
          <div class="flex-column flex-center gap-2">
            <i data-lucide="link-2-off" size="28"></i>
            <span>No matching reconciled records found.</span>
          </div>
        </td>
      </tr>
    `;
    lucide.createIcons();
    return;
  }

  filtered.forEach(p => {
    const tr = document.createElement('tr');
    
    // Compile details cell columns
    const dateA = formatDisplayDate(p.itemA.date);
    const dateB = formatDisplayDate(p.itemB.date);

    // Left Column Party A Details
    const cellA = `
      <div class="tx-composite-cell">
        <div class="tx-main-line">
          <span class="tx-partner">${p.itemA.particulars}</span>
          <span class="tx-val text-dr">₹${p.itemA.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
        </div>
        <div class="tx-sub-line">
          <span>${dateA}</span>
          <span class="divider">•</span>
          <span>Vch No: <strong>${p.itemA.vchNo || '(None)'}</strong></span>
          <span class="vch-badge">${p.itemA.vchType}</span>
        </div>
      </div>
    `;

    // Center Column Quality Indicators
    const cellCenter = `
      <div class="match-status-cell">
        <span class="badge-match-type ${p.matchType.toLowerCase()}">${p.matchType.replace('_', ' ')}</span>
        <span class="match-extra-meta">
          ${p.dateDiff > 0 ? `Transit Delay: ${p.dateDiff}d` : 'Same Day'}
          ${p.amountDiff !== 0 ? `<br><span class="text-dr">Diff: ₹${Math.abs(p.amountDiff).toFixed(2)}</span>` : ''}
          ${p.notes ? `<br><span class="label-sub">"${p.notes}"</span>` : ''}
          ${p.voucherTypeWarning ? `
            <span class="warning-icon-badge tooltip" title="Tally Voucher Types Mismatch! A lists '${p.itemA.vchType}' but B lists '${p.itemB.vchType}'">
              <i data-lucide="alert-triangle" size="13"></i>
            </span>
          ` : ''}
        </span>
      </div>
    `;

    // Right Column Party B Details
    const cellB = `
      <div class="tx-composite-cell">
        <div class="tx-main-line">
          <span class="tx-partner">${p.itemB.particulars}</span>
          <span class="tx-val text-cr">₹${p.itemB.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
        </div>
        <div class="tx-sub-line">
          <span>${dateB}</span>
          <span class="divider">•</span>
          <span>Vch No: <strong>${p.itemB.vchNo || '(None)'}</strong></span>
          <span class="vch-badge">${p.itemB.vchType}</span>
        </div>
      </div>
    `;

    tr.innerHTML = `
      <td class="col-a-header" style="width: 40%">${cellA}</td>
      <td class="col-center-header" style="width: 20%; padding: 0.5rem 0.25rem;">${cellCenter}</td>
      <td class="col-b-header" style="width: 40%">${cellB}</td>
      <td class="text-center" style="width: 10%">
        <button class="btn-unmatch" data-match-id="${p.id}">
          <i data-lucide="link-2-off" size="14"></i> Split
        </button>
      </td>
    `;

    // Unmatch Button click binder
    tr.querySelector('.btn-unmatch').addEventListener('click', (e) => {
      e.stopPropagation();
      undoReconciliation(p.id);
    });

    tbody.appendChild(tr);
  });

  // Re-init lucide icons on dynamically created components
  lucide.createIcons();
}

/**
 * Format date for high visual readability
 * e.g., "2024-04-12" -> "12-Apr-2024"
 */
function formatDisplayDate(dateStr) {
  if (!dateStr) return '';
  const parts = dateStr.split('-');
  if (parts.length !== 3) return dateStr;
  
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const monthIdx = parseInt(parts[1]) - 1;
  const displayMonth = months[monthIdx] || parts[1];
  
  return `${parts[2]}-${displayMonth}-${parts[0]}`;
}

/**
 * Generate highly structured multi-tab Excel spreadsheet from reconciliation results using SheetJS
 */
function exportReconciliationReport() {
  const res = AppState.reconciliationResult;
  if (!res) return;

  try {
    const wb = XLSX.utils.book_new();

    // ----------------------------------------------------
    // Tab 1: Executive Summary
    // ----------------------------------------------------
    const summaryData = [
      ["LedgerAlign PRO - Reconciliation Summary Report"],
      ["Generated On:", new Date().toLocaleDateString() + " " + new Date().toLocaleTimeString()],
      ["Ledger A File Name:", AppState.fileA.fileName],
      ["Ledger B File Name:", AppState.fileB.fileName],
      [],
      ["Key Metrics", "Value"],
      ["Reconciled Percentage:", `${res.stats.reconciliationPercentage}%`],
      ["Matched Volume (A + B Count):", res.stats.recompiledCount || (res.stats.reconciledA + res.stats.reconciledB)],
      ["Total Ledger A Records:", res.stats.totalA],
      ["Total Ledger B Records:", res.stats.totalB],
      ["Ledger A Unmatched Items:", res.unmatchedA.length],
      ["Ledger B Unmatched Items:", res.unmatchedB.length],
      [],
      ["Financial Balances", "Amount"],
      ["Ledger A Net Balance Directional:", `${res.stats.netA >= 0 ? 'Dr' : 'Cr'} ${Math.abs(res.stats.netA).toFixed(2)}`],
      ["Ledger B Net Balance Directional:", `${res.stats.netB >= 0 ? 'Dr' : 'Cr'} ${Math.abs(res.stats.netB).toFixed(2)}`],
      ["Out of Balance Variance Amount:", res.stats.variance.toFixed(2)],
      ["Status Summary:", res.stats.variance === 0 ? "LEDGERS PERFECTLY IN BALANCE" : "LEDGERS OUT OF BALANCE"]
    ];
    const wsSummary = XLSX.utils.aoa_to_sheet(summaryData);
    XLSX.utils.book_append_sheet(wb, wsSummary, "Executive Summary");

    // ----------------------------------------------------
    // Tab 2: Reconciled Entries
    // ----------------------------------------------------
    const reconciledHeaders = [
      "Match ID", "Match Type", "Transit delay (Days)", "Amount Diff", "Notes", 
      "A_Date", "A_Particulars", "A_VchNo", "A_VchType", "A_Amount",
      "B_Date", "B_Particulars", "B_VchNo", "B_VchType", "B_Amount"
    ];
    const reconciledRows = res.matchedPairs.map(p => [
      p.id, p.matchType, p.dateDiff, p.amountDiff, p.notes || '',
      p.itemA.date, p.itemA.particulars, p.itemA.vchNo, p.itemA.vchType, p.itemA.amount,
      p.itemB.date, p.itemB.particulars, p.itemB.vchNo, p.itemB.vchType, p.itemB.amount
    ]);
    const wsReconciled = XLSX.utils.json_to_sheet([reconciledHeaders, ...reconciledRows], { skipHeader: true });
    XLSX.utils.book_append_sheet(wb, wsReconciled, "Reconciled Entries");

    // ----------------------------------------------------
    // Tab 3: Unmatched Ledger A
    // ----------------------------------------------------
    const unmatchedAHeaders = ["Date", "Particulars", "Vch Type", "Vch No.", "Debit Amount", "Credit Amount", "Flow Direction"];
    const unmatchedARows = res.unmatchedA.map(tx => [
      tx.date, tx.particulars, tx.vchType, tx.vchNo, tx.debit || 0, tx.credit || 0, tx.type
    ]);
    const wsUnmatchedA = XLSX.utils.json_to_sheet([unmatchedAHeaders, ...unmatchedARows], { skipHeader: true });
    XLSX.utils.book_append_sheet(wb, wsUnmatchedA, "Unmatched Ledger A");

    // ----------------------------------------------------
    // Tab 4: Unmatched Ledger B
    // ----------------------------------------------------
    const unmatchedBHeaders = ["Date", "Particulars", "Vch Type", "Vch No.", "Debit Amount", "Credit Amount", "Flow Direction"];
    const unmatchedBRows = res.unmatchedB.map(tx => [
      tx.date, tx.particulars, tx.vchType, tx.vchNo, tx.debit || 0, tx.credit || 0, tx.type
    ]);
    const wsUnmatchedB = XLSX.utils.json_to_sheet([unmatchedBHeaders, ...unmatchedBRows], { skipHeader: true });
    XLSX.utils.book_append_sheet(wb, wsUnmatchedB, "Unmatched Ledger B");
    // Write Workbook
    const dateCode = new Date().toISOString().split('T')[0];
    XLSX.writeFile(wb, `Ledger_Reconciliation_Report_${dateCode}.xlsx`);
    showToast("Reconciliation Excel report downloaded successfully!", "success");
    } catch (error) {
      showToast("Failed to compile Excel file: " + error.message, "error");
    }
  }

/**
 * ==========================================================================
 * Premium Billing & Pricing Controller (Simulated Engine)
 * ==========================================================================
 */

// Initialize Billing State from LocalStorage
function initBillingState() {
  const stored = localStorage.getItem('ledgeralign_billing');
  if (stored && stored !== 'null' && stored !== 'undefined') {
    try {
      const parsed = JSON.parse(stored);
      if (parsed && typeof parsed === 'object') {
        AppState.billing = { ...AppState.billing, ...parsed };
      }
      if (AppState.billing.subscriptionExpiry && Date.now() > AppState.billing.subscriptionExpiry) {
        AppState.billing.activePlan = 'free';
        AppState.billing.subscriptionExpiry = null;
        saveBillingState();
      }
    } catch (e) {
      console.error('Failed to parse stored billing state, resetting:', e);
    }
  }
  updateBillingUI();
}

// Save Billing State to LocalStorage
function saveBillingState() {
  localStorage.setItem('ledgeralign_billing', JSON.stringify(AppState.billing));
  updateBillingUI();
}

// Update UI elements based on current plan and trial runs
function updateBillingUI() {
  const bill = AppState.billing || { reconciliationsRun: 0, activePlan: 'free', reconciliationsBalance: 0, subscriptionExpiry: null };
  const statusBadge = document.getElementById('lbl-billing-status');
  const trialBanner = document.getElementById('trial-banner');
  const trialTitle = document.getElementById('trial-banner-title');
  const trialDesc = document.getElementById('trial-banner-desc');
  
  if (!statusBadge) return;

  let planText = 'Free Trial';
  let bannerVisible = true;

  if (bill.activePlan === 'monthly') {
    const expDate = bill.subscriptionExpiry ? new Date(bill.subscriptionExpiry).toLocaleDateString('en-IN') : 'Active';
    planText = `PRO - Monthly (Exp: ${expDate})`;
    bannerVisible = false;
  } else if (bill.activePlan === 'yearly') {
    const expDate = bill.subscriptionExpiry ? new Date(bill.subscriptionExpiry).toLocaleDateString('en-IN') : 'Active';
    planText = `PRO - Yearly (Exp: ${expDate})`;
    bannerVisible = false;
  } else if (bill.activePlan === 'paygo') {
    planText = `PRO - Pay-As-You-Go (${bill.reconciliationsBalance} left)`;
    bannerVisible = bill.reconciliationsBalance <= 0;
    if (bill.reconciliationsBalance <= 0 && trialTitle && trialDesc) {
      trialTitle.textContent = "Balance Exhausted";
      trialDesc.textContent = "Your pay-as-you-go reconciliation balance is ₹0. Recharge or upgrade to a monthly/yearly plan to continue.";
    }
  } else {
    const remaining = Math.max(0, 2 - bill.reconciliationsRun);
    planText = `Free Trial: ${remaining} runs left`;
    if (trialTitle && trialDesc) {
      trialTitle.textContent = "Free Trial Active";
      trialDesc.textContent = `You have ${remaining} of 2 free reconciliations remaining. Upgrade to premium for unlimited matching and exports.`;
    }
    bannerVisible = true;
  }

  statusBadge.textContent = planText;
  
  if (trialBanner) {
    trialBanner.style.display = bannerVisible ? 'flex' : 'none';
  }
}

// Open Payment Paywall Modal
function openBillingModal(planId = 'monthly') {
  const modal = document.getElementById('billing-modal');
  if (!modal) return;

  document.getElementById('checkout-details-drawer').classList.remove('active');
  document.getElementById('checkout-gateway-loader').classList.remove('active');
  document.getElementById('checkout-success-view').classList.remove('active');
  document.getElementById('pricing-plans-grid').style.display = 'grid';

  selectPlanCard(planId, false);
  modal.classList.add('active');
}

// Select active plan card in UI
function selectPlanCard(planId, scrollIntoView = false) {
  document.querySelectorAll('#pricing-plans-grid .plan-card').forEach(card => {
    if (card.getAttribute('data-plan') === planId) {
      card.classList.add('active');
      const btn = card.querySelector('button.w-full');
      if (btn) btn.className = 'btn btn-primary w-full';
    } else {
      card.classList.remove('active');
      const btn = card.querySelector('button.w-full');
      if (btn) btn.className = 'btn btn-secondary w-full';
    }
  });

  const qtyWrapper = document.getElementById('paygo-quantity-wrapper');
  if (qtyWrapper) {
    qtyWrapper.style.display = planId === 'paygo' ? 'flex' : 'none';
  }

  updateOrderSummary(planId);
  
  const drawer = document.getElementById('checkout-details-drawer');
  if (drawer) {
    drawer.classList.add('active');
    if (scrollIntoView) {
      setTimeout(() => {
        drawer.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 150);
    }
  }
}

// Global checkout variables
let selectedQty = 1;

// Update summary costs panel based on card chosen
function updateOrderSummary(planId) {
  const planTitle = document.getElementById('lbl-summary-plan');
  const qtyRow = document.getElementById('summary-qty-row');
  const totalText = document.getElementById('lbl-summary-total');
  const paymentBtnText = document.getElementById('lbl-payment-btn-text');
  const qrImage = document.getElementById('upi-qr-image');

  let planName = 'Monthly Unlimited';
  let isQty = false;
  let basePrice = 500;

  if (planId === 'paygo') {
    planName = 'Pay-As-You-Go';
    isQty = true;
    basePrice = 100 * selectedQty;
  } else if (planId === 'yearly') {
    planName = 'Yearly Unlimited';
    basePrice = 7000;
  }

  if (planTitle) planTitle.textContent = planName;
  if (qtyRow) qtyRow.style.display = isQty ? 'flex' : 'none';
  
  const qtyLabel = document.getElementById('lbl-summary-qty');
  if (qtyLabel) qtyLabel.textContent = `${selectedQty} reconciliation${selectedQty > 1 ? 's' : ''}`;

  const grandTotal = basePrice;

  if (totalText) totalText.textContent = `₹${grandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
  if (paymentBtnText) paymentBtnText.textContent = `Secure Payment - Pay ₹${grandTotal.toLocaleString('en-IN')}`;

  if (qrImage) {
    const upiUri = `upi://pay?pa=caankitgupta777@oksbi&pn=Ankit Gupta&am=${grandTotal.toFixed(2)}&cu=INR`;
    qrImage.src = `https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=${encodeURIComponent(upiUri)}`;
  }
}

// Process Simulated Gateway Payment Transaction
function submitBillingPayment() {
  const tabCard = document.getElementById('tab-pay-card');
  const isCardActive = tabCard && tabCard.classList.contains('active');

  if (isCardActive) {
    const name = document.getElementById('txt-card-name').value.trim();
    const num = document.getElementById('txt-card-number').value.trim().replace(/\s+/g, '');
    const exp = document.getElementById('txt-card-expiry').value.trim();
    const cvv = document.getElementById('txt-card-cvv').value.trim();

    if (!name) {
      showToast("Please enter the Cardholder Name.", "error");
      return;
    }
    if (num.length < 16 || isNaN(num)) {
      showToast("Please enter a valid 16-digit Card Number.", "error");
      return;
    }
    if (!exp || !exp.includes('/')) {
      showToast("Please enter Expiry Date in MM/YY format.", "error");
      return;
    }
    const expParts = exp.split('/');
    const month = parseInt(expParts[0]);
    if (month < 1 || month > 12) {
      showToast("Please enter a valid expiry month (01-12).", "error");
      return;
    }
    if (cvv.length < 3 || isNaN(cvv)) {
      showToast("Please enter a valid 3-digit CVV number.", "error");
      return;
    }
  }

  const currentActivePlan = document.querySelector('#pricing-plans-grid .plan-card.active').getAttribute('data-plan');
  
  document.getElementById('checkout-details-drawer').classList.remove('active');
  document.getElementById('pricing-plans-grid').style.display = 'none';
  
  const loader = document.getElementById('checkout-gateway-loader');
  loader.classList.add('active');

  const steps = [
    "Securing bank-end terminal...",
    "Authorizing payment details with gateway...",
    "Completing final handshake..."
  ];
  
  let currentStep = 0;
  const title = loader.querySelector('h3');
  const stepInterval = setInterval(() => {
    if (currentStep < steps.length && title) {
      title.textContent = steps[currentStep];
      currentStep++;
    }
  }, 600);

  setTimeout(() => {
    clearInterval(stepInterval);
    loader.classList.remove('active');

    const txId = 'TXN-' + Math.floor(1000000000 + Math.random() * 9000000000);
    let planLabel = 'Monthly Unlimited';
    let chargedAmount = '₹500.00';
    let expiryLabel = 'Active for 30 Days';

    if (currentActivePlan === 'paygo') {
      planLabel = `Pay-As-You-Go (Purchased ${selectedQty} runs)`;
      chargedAmount = `₹${(100 * selectedQty).toLocaleString('en-IN')}.00`;
      expiryLabel = 'No Expiry (Lifetime validity)';

      AppState.billing.activePlan = 'paygo';
      AppState.billing.reconciliationsBalance += selectedQty;
      AppState.billing.subscriptionExpiry = null;
    } else if (currentActivePlan === 'yearly') {
      planLabel = 'Yearly Unlimited';
      chargedAmount = '₹7,000.00';
      const yearExp = new Date();
      yearExp.setFullYear(yearExp.getFullYear() + 1);
      expiryLabel = yearExp.toLocaleDateString('en-IN');

      AppState.billing.activePlan = 'yearly';
      AppState.billing.subscriptionExpiry = yearExp.getTime();
      AppState.billing.reconciliationsBalance = 0;
    } else {
      planLabel = 'Monthly Unlimited';
      chargedAmount = '₹500.00';
      const monthExp = new Date();
      monthExp.setMonth(monthExp.getMonth() + 1);
      expiryLabel = monthExp.toLocaleDateString('en-IN');

      AppState.billing.activePlan = 'monthly';
      AppState.billing.subscriptionExpiry = monthExp.getTime();
      AppState.billing.reconciliationsBalance = 0;
    }

    saveBillingState();

    document.getElementById('receipt-tx-id').textContent = txId;
    document.getElementById('receipt-plan-name').textContent = planLabel;
    document.getElementById('receipt-amount').textContent = chargedAmount;
    document.getElementById('receipt-expiry').textContent = expiryLabel;

    const successView = document.getElementById('checkout-success-view');
    successView.classList.add('active');
    lucide.createIcons();

  }, 1800);
}

// Reset Billing State Developer Utility
function resetBillingState() {
  AppState.billing = {
    reconciliationsRun: 0,
    activePlan: 'free',
    reconciliationsBalance: 0,
    subscriptionExpiry: null
  };
  saveBillingState();
  
  selectedQty = 1;
  const qtySpan = document.getElementById('lbl-paygo-qty');
  if (qtySpan) qtySpan.textContent = '1';

  showToast("Billing state reset successfully! Trial restored.", "success");
  
  const modal = document.getElementById('billing-modal');
  if (modal) modal.classList.remove('active');
}
