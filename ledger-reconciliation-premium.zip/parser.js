/**
 * parser.js
 * Ledger Parser & Normalizer
 * Designed to parse Tally ERP exports and generic Excel/CSV spreadsheets.
 */

const Parser = {
  // Common column header synonyms for auto-mapping
  Synonyms: {
    date: ['date', 'dt', 'txn date', 'transaction date', 'posting date', 'value date'],
    particulars: ['particulars', 'description', 'narrative', 'details', 'particular', 'ledger', 'party', 'account'],
    vchType: ['vch type', 'voucher type', 'type', 'transaction type', 'vch_type'],
    vchNo: ['vch no', 'voucher no', 'voucher number', 'ref no', 'reference', 'ref number', 'document no', 'doc no', 'chq no', 'instrument no'],
    debit: ['debit', 'dr', 'dr amount', 'debit amount', 'withdrawal', 'payment', 'paid', 'cash out'],
    credit: ['credit', 'cr', 'cr amount', 'credit amount', 'deposit', 'receipt', 'received', 'cash in'],
    amount: ['amount', 'amt', 'value', 'balance amount', 'total amount']
  },

  // Voucher type normalizer mapping
  VoucherTypes: {
    // Sales / Revenue
    'sales': 'SALES',
    'sale': 'SALES',
    'invoice': 'SALES',
    'inv': 'SALES',
    'purchase': 'PURCHASE',
    'purc': 'PURCHASE',
    'pur': 'PURCHASE',
    
    // Payments / Receipts
    'receipt': 'RECEIPT',
    'rcpt': 'RECEIPT',
    'payment': 'PAYMENT',
    'pymt': 'PAYMENT',
    'pay': 'PAYMENT',

    // Notes
    'credit note': 'CREDIT_NOTE',
    'cr note': 'CREDIT_NOTE',
    'cn': 'CREDIT_NOTE',
    'debit note': 'DEBIT_NOTE',
    'dr note': 'DEBIT_NOTE',
    'dn': 'DEBIT_NOTE',

    // Journal
    'journal': 'JOURNAL',
    'jrnl': 'JOURNAL',
    'jv': 'JOURNAL',
    'contra': 'CONTRA'
  },

  /**
   * Parse uploaded Excel or CSV file.
   * Uses SheetJS (XLSX) to convert file to array of arrays.
   * @param {File} file - Excel or CSV File object
   * @returns {Promise<Array<Array<any>>>} - Raw sheet matrix
   */
  async parseRawFile(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target.result);
          const workbook = XLSX.read(data, { type: 'array', cellDates: true, raw: false });
          
          // Get the first worksheet
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          
          // Convert sheet to 2D Array
          const rawRows = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: "" });
          resolve(rawRows);
        } catch (error) {
          reject(new Error("Failed to parse file structure. Ensure it is a valid Excel or CSV. Details: " + error.message));
        }
      };

      reader.onerror = () => {
        reject(new Error("Failed to read file."));
      };

      reader.readAsArrayBuffer(file);
    });
  },

  /**
   * Intelligently crop raw sheet data to isolate transaction rows.
   * Tally exports have header text, empty rows, and total lines.
   * @param {Array<Array<any>>} rawRows
   * @returns {{headerRowIndex: number, endRowIndex: number, cleanHeaders: string[]}}
   */
  detectTableBounds(rawRows) {
    let headerRowIndex = -1;
    let endRowIndex = rawRows.length;
    let maxHeaderScore = 0;

    // 1. Scan for the table header row
    for (let r = 0; r < Math.min(rawRows.length, 100); r++) {
      const row = rawRows[r];
      if (!row || row.length === 0) continue;

      let score = 0;
      row.forEach(cell => {
        if (cell === null || cell === undefined) return;
        const txt = String(cell).toLowerCase().trim();
        
        // Count how many known ledger header synonyms are matched
        Object.keys(Parser.Synonyms).forEach(key => {
          if (Parser.Synonyms[key].includes(txt)) {
            score += 2; // Exact match on synonym
          } else if (Parser.Synonyms[key].some(syn => txt.includes(syn))) {
            score += 1; // Partial match
          }
        });
      });

      if (score > maxHeaderScore && score >= 3) {
        maxHeaderScore = score;
        headerRowIndex = r;
      }
    }

    // Default fallback if no header matches well: first non-empty row containing "date"
    if (headerRowIndex === -1) {
      for (let r = 0; r < Math.min(rawRows.length, 50); r++) {
        const row = rawRows[r];
        if (row && row.some(cell => String(cell).toLowerCase().includes('date'))) {
          headerRowIndex = r;
          break;
        }
      }
    }

    // If still not found, start at index 0
    if (headerRowIndex === -1) {
      headerRowIndex = 0;
    }

    // 2. Scan downwards from header to find the end row
    // We stop at rows containing "total", "closing balance", "opening balance" (at the very bottom),
    // or if we encounter structural breaks.
    const headers = rawRows[headerRowIndex].map(h => String(h).trim());
    const particularsIdx = headers.findIndex(h => {
      const txt = h.toLowerCase();
      return Parser.Synonyms.particulars.includes(txt) || txt.includes('particular');
    });

    for (let r = headerRowIndex + 1; r < rawRows.length; r++) {
      const row = rawRows[r];
      if (!row || row.length === 0) continue;

      // Check particulars column or check whole row for totals/closing indicator
      let isEnd = false;
      const cellText = particularsIdx !== -1 && row[particularsIdx] ? String(row[particularsIdx]) : "";
      
      const checkText = (cellText + " " + row.join(" ")).toLowerCase();
      
      if (
        checkText.includes('grand total') ||
        checkText.includes('closing balance') ||
        (checkText.includes('total') && (checkText.includes('debit') || checkText.includes('credit') || r > rawRows.length - 5))
      ) {
        endRowIndex = r;
        break;
      }
    }

    return {
      headerRowIndex,
      endRowIndex,
      cleanHeaders: headers
    };
  },

  /**
   * Propose a column mapping based on detected headers.
   * @param {string[]} headers 
   * @returns {Object} - Keyed by standard fields, values are header indices
   */
  proposeColumnMapping(headers) {
    const mapping = {
      date: -1,
      particulars: -1,
      vchType: -1,
      vchNo: -1,
      debit: -1,
      credit: -1,
      amount: -1
    };

    headers.forEach((header, index) => {
      if (!header) return;
      const txt = header.toLowerCase().trim();

      Object.keys(Parser.Synonyms).forEach(field => {
        const synonyms = Parser.Synonyms[field];
        if (mapping[field] === -1) {
          if (synonyms.includes(txt)) {
            mapping[field] = index;
          } else if (synonyms.some(syn => txt.includes(syn) || syn.includes(txt))) {
            // Keep as secondary match
            mapping[field] = index;
          }
        }
      });
    });

    // If debit/credit are mapped but amount is also mapped, prioritize debit/credit
    // If debit/credit are missing but amount is available, make sure amount is mapped
    return mapping;
  },

  /**
   * Parse a date string into YYYY-MM-DD. Supports Excel date numbers, DD-MM-YYYY, DD-MMM-YYYY (12-Apr-2023), etc.
   * @param {any} cellVal 
   * @returns {string} - YYYY-MM-DD or empty string if invalid
   */
  parseDate(cellVal) {
    if (!cellVal) return '';

    // If it's already a JS Date object
    if (cellVal instanceof Date) {
      return cellVal.toISOString().split('T')[0];
    }

    const str = String(cellVal).trim();
    if (!str) return '';

    // Tally often uses DD-MMM-YYYY (e.g. 1-Apr-2024 or 12-Apr-24 or 12-April-2024)
    // First, let's clean spaces and replace slashes or dots with hyphens
    let cleaned = str.replace(/[\s./]/g, '-');

    // Parse DD-MMM-YYYY format
    const months = {
      jan: '01', feb: '02', mar: '03', apr: '04', may: '05', jun: '06',
      jul: '07', aug: '08', sep: '09', oct: '10', nov: '11', dec: '12',
      january: '01', february: '02', march: '03', april: '04', june: '06',
      july: '07', august: '08', september: '09', october: '10', november: '11', december: '12'
    };

    const parts = cleaned.split('-');
    if (parts.length === 3) {
      let day = parts[0].padStart(2, '0');
      let monthStr = parts[1].toLowerCase();
      let year = parts[2];

      // Handle month text
      if (months[monthStr]) {
        monthStr = months[monthStr];
      } else if (!isNaN(monthStr)) {
        monthStr = monthStr.padStart(2, '0');
      }

      // Handle 2 digit year
      if (year.length === 2) {
        const yrNum = parseInt(year);
        year = (yrNum > 50 ? '19' : '20') + year;
      }

      if (!isNaN(day) && !isNaN(monthStr) && !isNaN(year)) {
        return `${year}-${monthStr}-${day}`;
      }
    }

    // Try standard JS Date parsing fallback
    const parsedDate = new Date(str);
    if (!isNaN(parsedDate.getTime())) {
      return parsedDate.toISOString().split('T')[0];
    }

    return '';
  },

  /**
   * Parse a numeric value from string (removes currency symbols, commas, handles CR/DR signs if present)
   * @param {any} cellVal 
   * @returns {number} - Parsed float
   */
  parseAmount(cellVal) {
    if (cellVal === null || cellVal === undefined) return 0;
    
    let str = String(cellVal).trim();
    if (!str) return 0;

    // Handle Dr / Cr markers at end or beginning
    let multiplier = 1;
    if (str.toLowerCase().includes('cr') || str.includes('-')) {
      multiplier = -1; // Wait, let's keep all positive, or let the ledger parser classify.
      // In Tally, Credit can be represented as positive in Credit col or with "Cr".
      // To prevent sign confusion, we extract pure numbers and let the column structure (Debit vs Credit) dictate the sign.
    }
    
    // Strip everything except digits, dots, and negative signs
    let numStr = str.replace(/[^0-9.-]/g, '');
    let val = parseFloat(numStr);
    
    return isNaN(val) ? 0 : val;
  },

  /**
   * Normalize voucher type name
   * @param {string} rawType 
   * @returns {string} - Unified type name
   */
  normalizeVoucherType(rawType) {
    if (!rawType) return 'JOURNAL'; // Default fallback
    const clean = String(rawType).toLowerCase().trim();

    // Check direct matching keys
    for (const key of Object.keys(Parser.VoucherTypes)) {
      if (clean.includes(key)) {
        return Parser.VoucherTypes[key];
      }
    }

    return 'JOURNAL'; // Default fallback if no match
  },

  /**
   * Transform raw data matrix into structured transaction records.
   * @param {Array<Array<any>>} rawRows 
   * @param {Object} bounds - {headerRowIndex, endRowIndex}
   * @param {Object} mapping - Propose column mapping
   * @returns {Array<Object>} - Standardized transactions
   */
  standardizeTransactions(rawRows, bounds, mapping) {
    const transactions = [];
    let runningBalance = 0;

    for (let r = bounds.headerRowIndex + 1; r < bounds.endRowIndex; r++) {
      const row = rawRows[r];
      if (!row || row.length === 0) continue;

      // Skip lines that are empty or are intermediate titles / opening balances
      const particularsCell = mapping.particulars !== -1 ? String(row[mapping.particulars] || "").trim() : "";
      if (!particularsCell || particularsCell.toLowerCase().includes("opening balance") || particularsCell.toLowerCase() === "balance b/f") {
        continue;
      }

      // Extract transaction date
      const rawDate = mapping.date !== -1 ? row[mapping.date] : "";
      const date = Parser.parseDate(rawDate);
      if (!date) continue; // Every valid ledger entry MUST have a date

      // Extract details
      const particulars = particularsCell;
      const vchType = mapping.vchType !== -1 ? Parser.normalizeVoucherType(row[mapping.vchType]) : 'JOURNAL';
      const vchNo = mapping.vchNo !== -1 ? String(row[mapping.vchNo] || "").trim() : "";

      // Extract Debit / Credit amounts
      let debit = 0;
      let credit = 0;

      if (mapping.debit !== -1) {
        debit = Parser.parseAmount(row[mapping.debit]);
      }
      if (mapping.credit !== -1) {
        credit = Parser.parseAmount(row[mapping.credit]);
      }

      // If separate debit/credit columns are not mapped or are empty, check the combined amount column
      if (mapping.debit === -1 && mapping.credit === -1 && mapping.amount !== -1) {
        const amtVal = Parser.parseAmount(row[mapping.amount]);
        const amtStr = String(row[mapping.amount]).toLowerCase();
        
        // Infer direction based on standard ledger labels (Dr, Cr, Credit, Debit, Cash Out, Cash In)
        if (amtStr.includes('cr') || amtStr.includes('credit') || amtVal < 0) {
          credit = Math.abs(amtVal);
        } else {
          debit = Math.abs(amtVal);
        }
      }

      // Skip empty transactions (zero debit and credit)
      if (debit === 0 && credit === 0) continue;

      // Generate a unique ID for processing
      const id = `tx_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

      transactions.push({
        id,
        date,
        particulars,
        vchType,
        vchNo,
        debit,
        credit,
        amount: debit > 0 ? debit : credit,
        type: debit > 0 ? 'DR' : 'CR'
      });
    }

    return transactions;
  }
};
