/**
 * matcher.js
 * Ledger Reconciliation Matching Engine
 * Handles the logic for matching transactions from two separate party books.
 */

const Matcher = {
  // Voucher Compatibility Matrix
  VoucherCompatibility: {
    SALES: ['PURCHASE', 'JOURNAL'],
    PURCHASE: ['SALES', 'JOURNAL'],
    RECEIPT: ['PAYMENT', 'JOURNAL'],
    PAYMENT: ['RECEIPT', 'JOURNAL'],
    CREDIT_NOTE: ['DEBIT_NOTE', 'JOURNAL'],
    DEBIT_NOTE: ['CREDIT_NOTE', 'JOURNAL'],
    JOURNAL: ['JOURNAL', 'SALES', 'PURCHASE', 'RECEIPT', 'PAYMENT', 'CREDIT_NOTE', 'DEBIT_NOTE', 'CONTRA'],
    CONTRA: ['CONTRA', 'JOURNAL']
  },

  /**
   * Helper to check if two voucher types are theoretically compatible
   */
  areVoucherTypesCompatible(typeA, typeB) {
    if (!typeA || !typeB) return true;
    const targets = Matcher.VoucherCompatibility[typeA] || [];
    return targets.includes(typeB) || Matcher.VoucherCompatibility[typeB]?.includes(typeA);
  },

  /**
   * Normalize reference numbers for fuzzy matching
   * Strips all spaces, slashes, dashes, dots, leading zeros, and lowercases.
   * e.g., "INV/2023-24/005" -> "inv2023245"
   */
  normalizeRef(ref) {
    if (!ref) return '';
    let cleaned = String(ref)
      .toLowerCase()
      .replace(/[^a-z0-9]/g, ''); // Keep alphanumeric only
    
    // Strip leading zeros from numeric portions
    cleaned = cleaned.replace(/\b0+(\d+)/g, '$1');
    return cleaned;
  },

  /**
   * Calculate absolute difference in days between two YYYY-MM-DD date strings
   */
  getDateDiffDays(dateStrA, dateStrB) {
    const dA = new Date(dateStrA);
    const dB = new Date(dateStrB);
    if (isNaN(dA.getTime()) || isNaN(dB.getTime())) return 99999;
    const diffTime = Math.abs(dA - dB);
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  },

  /**
   * Check if amounts match within rounding tolerance
   */
  isAmountMatch(amtA, amtB, tolerance = 1.0) {
    return Math.abs(amtA - amtB) <= tolerance;
  },

  /**
   * Reconcile two ledgers using the multi-pass algorithm
   * 
   * @param {Array<Object>} ledgerA - Standardized Ledger A
   * @param {Array<Object>} ledgerB - Standardized Ledger B
   * @param {Object} options - Matching options
   * @returns {Object} - Matching results containing matches, mismatches, and stats
   */
  reconcile(ledgerA, ledgerB, options = {}) {
    const dateTolerance = options.dateTolerance !== undefined ? parseInt(options.dateTolerance) : 7;
    const roundingTolerance = options.roundingTolerance !== undefined ? parseFloat(options.roundingTolerance) : 1.0;
    const useVoucherTypes = options.useVoucherTypes !== undefined ? options.useVoucherTypes : true;

    // Make deep copies to track state and matched status
    const listA = ledgerA.map(tx => ({ ...tx, matched: false, matchId: null }));
    const listB = ledgerB.map(tx => ({ ...tx, matched: false, matchId: null }));

    const matchedPairs = [];

    // Helper to log a match
    const recordMatch = (itemA, itemB, matchType, amountDiff = 0, notes = '') => {
      const matchId = `match_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      itemA.matched = true;
      itemA.matchId = matchId;
      itemB.matched = true;
      itemB.matchId = matchId;

      matchedPairs.push({
        id: matchId,
        itemA: { ...itemA, matched: true, matchId },
        itemB: { ...itemB, matched: true, matchId },
        matchType,
        amountDiff,
        dateDiff: Matcher.getDateDiffDays(itemA.date, itemB.date),
        notes,
        voucherTypeWarning: useVoucherTypes && !Matcher.areVoucherTypesCompatible(itemA.vchType, itemB.vchType)
      });
    };

    // Rule: DR in Ledger A matches CR in Ledger B, and CR in Ledger A matches DR in Ledger B
    const isMatchingDirection = (itemA, itemB) => {
      return itemA.type !== itemB.type;
    };

    // ----------------------------------------------------
    // PASS 1: Exact Match (Exact Date, Exact Ref, Exact Amount, Opposite Direction)
    // ----------------------------------------------------
    for (const itemA of listA) {
      if (itemA.matched) continue;
      
      const perfectMatch = listB.find(itemB => 
        !itemB.matched &&
        isMatchingDirection(itemA, itemB) &&
        itemA.date === itemB.date &&
        itemA.amount === itemB.amount &&
        itemA.vchNo && itemB.vchNo &&
        itemA.vchNo.toLowerCase().trim() === itemB.vchNo.toLowerCase().trim()
      );

      if (perfectMatch) {
        recordMatch(itemA, perfectMatch, 'EXACT');
      }
    }

    // ----------------------------------------------------
    // PASS 2: Timing Match (Exact Ref, Exact Amount, Dates within Tolerance, Opposite Direction)
    // ----------------------------------------------------
    for (const itemA of listA) {
      if (itemA.matched) continue;

      // Find compatible unmatched items in B with the same reference and amount
      const candidates = listB.filter(itemB =>
        !itemB.matched &&
        isMatchingDirection(itemA, itemB) &&
        itemA.amount === itemB.amount &&
        itemA.vchNo && itemB.vchNo &&
        Matcher.normalizeRef(itemA.vchNo) === Matcher.normalizeRef(itemB.vchNo)
      );

      if (candidates.length > 0) {
        // Find the one closest in date
        let bestMatch = null;
        let minDays = Infinity;
        
        candidates.forEach(itemB => {
          const days = Matcher.getDateDiffDays(itemA.date, itemB.date);
          if (days < minDays && days <= dateTolerance) {
            minDays = days;
            bestMatch = itemB;
          }
        });

        if (bestMatch) {
          recordMatch(itemA, bestMatch, 'TIMING', 0, `Date offset of ${minDays} days`);
        }
      }
    }

    // ----------------------------------------------------
    // PASS 3: Rounding Match with Reference (Exact or Fuzzy Ref, Amounts within Rounding Tolerance, Dates within Tolerance, Opposite Direction)
    // ----------------------------------------------------
    if (roundingTolerance > 0) {
      for (const itemA of listA) {
        if (itemA.matched) continue;

        const candidates = listB.filter(itemB =>
          !itemB.matched &&
          isMatchingDirection(itemA, itemB) &&
          Matcher.isAmountMatch(itemA.amount, itemB.amount, roundingTolerance) &&
          itemA.amount !== itemB.amount && // Only handle discrepancies here, exact matches done
          itemA.vchNo && itemB.vchNo &&
          Matcher.normalizeRef(itemA.vchNo) === Matcher.normalizeRef(itemB.vchNo)
        );

        if (candidates.length > 0) {
          let bestMatch = null;
          let minDays = Infinity;

          candidates.forEach(itemB => {
            const days = Matcher.getDateDiffDays(itemA.date, itemB.date);
            if (days < minDays && days <= dateTolerance) {
              minDays = days;
              bestMatch = itemB;
            }
          });

          if (bestMatch) {
            const diff = itemA.amount - bestMatch.amount;
            recordMatch(itemA, bestMatch, 'ROUNDING', diff, `Matched with rounding difference of ${diff.toFixed(2)}`);
          }
        }
      }
    }

    // ----------------------------------------------------
    // PASS 4: Fuzzy Match (Fuzzy Ref / Similar Particulars, Same Amount, Dates within Tolerance, Opposite Direction)
    // ----------------------------------------------------
    for (const itemA of listA) {
      if (itemA.matched) continue;

      const candidates = listB.filter(itemB => 
        !itemB.matched &&
        isMatchingDirection(itemA, itemB) &&
        itemA.amount === itemB.amount
      );

      if (candidates.length > 0) {
        let bestMatch = null;
        let minDays = Infinity;
        let isFuzzyRefMatch = false;

        candidates.forEach(itemB => {
          const days = Matcher.getDateDiffDays(itemA.date, itemB.date);
          if (days <= dateTolerance && days < minDays) {
            // Check reference fuzzy compatibility
            const normA = Matcher.normalizeRef(itemA.vchNo);
            const normB = Matcher.normalizeRef(itemB.vchNo);
            
            // Check if one reference is a substring of another, or if they share normalized content
            const isRefMatch = (normA && normB) && (normA.includes(normB) || normB.includes(normA));
            
            // Or if particulars match closely (fuzzy text comparison)
            const descA = itemA.particulars.toLowerCase();
            const descB = itemB.particulars.toLowerCase();
            const isDescMatch = descA.includes(descB) || descB.includes(descA) || 
                                (descA.split(' ').some(w => w.length > 3 && descB.includes(w)));

            if (isRefMatch || isDescMatch) {
              minDays = days;
              bestMatch = itemB;
              isFuzzyRefMatch = true;
            }
          }
        });

        if (bestMatch) {
          recordMatch(itemA, bestMatch, 'FUZZY', 0, `Fuzzy reference or description match within ${minDays} days`);
        }
      }
    }

    // ----------------------------------------------------
    // PASS 5: Reference Mismatch / Amount Only Match (Same Amount, Same/Close Date, Different Ref, Opposite Direction)
    // Useful for highlighting transactions that occurred on the same day but references weren't entered.
    // ----------------------------------------------------
    for (const itemA of listA) {
      if (itemA.matched) continue;

      // Find unmatched items in B with exact amount and close date (within 2 days), but different reference
      const match = listB.find(itemB =>
        !itemB.matched &&
        isMatchingDirection(itemA, itemB) &&
        itemA.amount === itemB.amount &&
        Matcher.getDateDiffDays(itemA.date, itemB.date) <= Math.min(2, dateTolerance)
      );

      if (match) {
        recordMatch(itemA, match, 'AMOUNT_ONLY', 0, 'Matched by Amount and Date only (Reference Mismatch)');
      }
    }

    // Assemble final statistics
    const totalTransactionsA = listA.length;
    const totalTransactionsB = listB.length;
    
    const reconciledA = listA.filter(x => x.matched);
    const reconciledB = listB.filter(x => x.matched);

    const unmatchedA = listA.filter(x => !x.matched);
    const unmatchedB = listB.filter(x => !x.matched);

    // Sum totals
    const totalDebitA = listA.reduce((sum, x) => sum + (x.debit || 0), 0);
    const totalCreditA = listA.reduce((sum, x) => sum + (x.credit || 0), 0);
    const totalDebitB = listB.reduce((sum, x) => sum + (x.debit || 0), 0);
    const totalCreditB = listB.reduce((sum, x) => sum + (x.credit || 0), 0);

    const netA = totalDebitA - totalCreditA;
    const netB = totalDebitB - totalCreditB; // Note: mirror image, so ideally Net A + Net B = 0 if perfectly aligned

    return {
      matchedPairs,
      unmatchedA,
      unmatchedB,
      stats: {
        totalA: totalTransactionsA,
        totalB: totalTransactionsB,
        reconciledA: reconciledA.length,
        reconciledB: reconciledB.length,
        unmatchedA: unmatchedA.length,
        unmatchedB: unmatchedB.length,
        totalDebitA,
        totalCreditA,
        totalDebitB,
        totalCreditB,
        netA,
        netB,
        variance: netA + netB, // Out of balance amount
        reconciliationPercentage: Math.round(((reconciledA.length + reconciledB.length) / (totalTransactionsA + totalTransactionsB || 1)) * 100)
      }
    };
  }
};
